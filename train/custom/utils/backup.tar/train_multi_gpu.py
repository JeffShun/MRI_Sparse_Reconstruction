import warnings
warnings.filterwarnings('ignore')
import os
from config.model_config import network_cfg
import torch
from torch import optim
from torch.autograd import Variable as V
import time
from custom.utils.logger import Logger
from custom.utils.model_backup import model_backup
from custom.utils.lr_scheduler import WarmupMultiStepLR
from custom.utils.dataloaderX import DataLoaderX
from custom.utils.distributed_utils import *
import torch.distributed as dist
from custom.utils.tensorboad_utils import get_writer, display_img
from torchvision.utils import save_image
import shutil

def train():  

    # 分布式训练初始化
    init_distributed_mode(network_cfg)
    rank = network_cfg.rank
    device = network_cfg.device

    # 训练准备
    logger_dir = network_cfg.log_dir
    tensorboad_dir = logger_dir + "/tf_logs"
    os.makedirs(network_cfg.gen_checkpoints_dir,exist_ok=True)
    os.makedirs(network_cfg.disc_checkpoints_dir,exist_ok=True)
    os.makedirs(logger_dir, exist_ok=True)
    if rank == 0:
        model_backup(logger_dir+"/backup.tar")
        if os.path.exists(tensorboad_dir): 
            shutil.rmtree(tensorboad_dir)
    logger = Logger(logger_dir+"/trainlog.txt", level='debug').logger
    writer = get_writer(tensorboad_dir)

    # 网络定义
    GenNet = network_cfg.gen_network.cuda()
    DiscNet = network_cfg.disc_network.cuda()
    # 定义损失函数
    train_gen_loss_f = network_cfg.train_gen_loss_f
    train_disc_loss_f = network_cfg.train_disc_loss_f
    valid_loss_f = network_cfg.valid_loss_f
    # 学习率要根据并行GPU的数量进行倍增
    network_cfg.lr *= network_cfg.world_size  
    GenNet = network_cfg.gen_network.to(device)
    GenNet = torch.nn.SyncBatchNorm.convert_sync_batchnorm(GenNet)
    DiscNet = network_cfg.disc_network.to(device)
    DiscNet = torch.nn.SyncBatchNorm.convert_sync_batchnorm(DiscNet)
    gen_init_weight = os.path.join(network_cfg.gen_checkpoints_dir, "initial_weights.pth")
    disc_init_weight = os.path.join(network_cfg.disc_checkpoints_dir, "initial_weights.pth")
    # 如果存在预训练权重则载入
    if os.path.exists(network_cfg.gen_load_from):
        if rank == 0:
            print("Load pretrain gen weight from: " + network_cfg.gen_load_from)
        GenNet.load_state_dict(torch.load(network_cfg.gen_load_from, map_location=network_cfg.device))
    if os.path.exists(network_cfg.disc_load_from):
        if rank == 0:
            print("Load pretrain disc weight from: " + network_cfg.disc_load_from)
        DiscNet.load_state_dict(torch.load(network_cfg.disc_load_from))
    else:
        # 如果不存在预训练权重，需要将第一个进程中的权重保存，然后其他进程载入，保持初始化权重一致
        if rank == 0:
            torch.save(GenNet.state_dict(), gen_init_weight)
            torch.save(DiscNet.state_dict(), disc_init_weight)
        dist.barrier()
        # 这里注意，一定要指定map_location参数，否则会导致第一块GPU占用更多资源
        GenNet.load_state_dict(torch.load(gen_init_weight, map_location=device))
        DiscNet.load_state_dict(torch.load(disc_init_weight, map_location=device))

    # 转为DDP模型
    GenNet = torch.nn.parallel.DistributedDataParallel(GenNet, device_ids=[network_cfg.gpu])
    DiscNet = torch.nn.parallel.DistributedDataParallel(DiscNet, device_ids=[network_cfg.gpu])

    train_dataset = network_cfg.train_dataset
    train_sampler = torch.utils.data.distributed.DistributedSampler(train_dataset, shuffle=network_cfg.shuffle)
    train_dataloader = DataLoaderX(dataset = train_dataset, 
                                batch_size = network_cfg.batchsize,
                                num_workers=network_cfg.num_workers,
                                sampler = train_sampler,
                                drop_last=network_cfg.drop_last,
                                pin_memory = True
                                )               
                    
    valid_dataset = network_cfg.valid_dataset
    valid_sampler = torch.utils.data.distributed.DistributedSampler(valid_dataset, shuffle=False)
    valid_dataloader = DataLoaderX(dataset = valid_dataset, 
                                batch_size = network_cfg.batchsize,                                
                                num_workers=network_cfg.num_workers, 
                                sampler = valid_sampler,
                                drop_last=False,
                                pin_memory = True
                                )

    optimizer_gen = optim.AdamW(params=GenNet.parameters(), lr=network_cfg.lr, weight_decay=network_cfg.weight_decay)
    optimizer_disc = optim.AdamW(params=DiscNet.parameters(), lr=network_cfg.lr, weight_decay=network_cfg.weight_decay)
    
    scheduler_gen = WarmupMultiStepLR(optimizer=optimizer_gen,
                                milestones=network_cfg.milestones,
                                gamma=network_cfg.gamma,
                                warmup_factor=network_cfg.warmup_factor,
                                warmup_iters=network_cfg.warmup_iters,
                                warmup_method=network_cfg.warmup_method,
                                last_epoch=network_cfg.last_epoch)
    
    scheduler_dic = WarmupMultiStepLR(optimizer=optimizer_disc,
                                milestones=network_cfg.milestones,
                                gamma=network_cfg.gamma,
                                warmup_factor=network_cfg.warmup_factor,
                                warmup_iters=network_cfg.warmup_iters,
                                warmup_method=network_cfg.warmup_method,
                                last_epoch=network_cfg.last_epoch)

    time_start=time.time()
    for epoch in range(network_cfg.total_epochs): 
        train_sampler.set_epoch(epoch)
        #Training Step!
        GenNet.train()
        DiscNet.train()
        for ii, (src_img, tgt_img) in enumerate(train_dataloader):
            src_img = V(src_img).to(device)
            tgt_img = V(tgt_img).to(device)
            t_out = GenNet(src_img)

            # discriminator step
            t_disc_loss = train_disc_loss_f(t_out, tgt_img, DiscNet)
            disc_loss = V(torch.zeros(1)).to(device)
            loss_info = ""
            for loss_item, loss_val in t_disc_loss.items():
                disc_loss += loss_val
                loss_info += "{}={:.4f}\t ".format(loss_item,loss_val.item())
                if rank == 0:
                    writer.add_scalar('TrainDiscLoss/{}'.format(loss_item),loss_val.item(), epoch*len(train_dataloader)+ii+1)
            time_temp=time.time()
            eta = ((network_cfg.total_epochs-epoch)+(1-(ii+1)/len(train_dataloader)))/(epoch+(ii+1)/len(train_dataloader))*(time_temp-time_start)/60
            if eta < 60:
                eta = "{:.1f}min".format(eta)
            else:
                eta = "{:.1f}h".format(eta/60.0)
            if rank == 0:
                logger.info('Epoch:[{}/{}]\t Iter:[{}/{}]\t Eta:{}\t {}'.format(epoch+1 ,network_cfg.total_epochs, ii+1, len(train_dataloader), eta, loss_info))
            optimizer_disc.zero_grad()
            disc_loss.backward()
            optimizer_disc.step()

            # generator step
            t_gen_loss = train_gen_loss_f(t_out, tgt_img, DiscNet)
            gen_loss = V(torch.zeros(1)).to(device)
            loss_info = ""
            for loss_item, loss_val in t_gen_loss.items():
                gen_loss += loss_val
                loss_info += "{}={:.4f}\t ".format(loss_item,loss_val.item())
                if rank == 0:
                    writer.add_scalar('TrainGenLoss/{}'.format(loss_item),loss_val.item(), epoch*len(train_dataloader)+ii+1)
            time_temp=time.time()
            eta = ((network_cfg.total_epochs-epoch)+(1-(ii+1)/len(train_dataloader)))/(epoch+(ii+1)/len(train_dataloader))*(time_temp-time_start)/60
            if eta < 60:
                eta = "{:.1f}min".format(eta)
            else:
                eta = "{:.1f}h".format(eta/60.0)
            if rank == 0:
                logger.info('Epoch:[{}/{}]\t Iter:[{}/{}]\t Eta:{}\t {}'.format(epoch+1 ,network_cfg.total_epochs, ii+1, len(train_dataloader), eta, loss_info))
            optimizer_gen.zero_grad()
            gen_loss.backward()
            optimizer_gen.step()

        if rank == 0:
            writer.add_scalar('LR', optimizer_disc.state_dict()['param_groups'][0]['lr'], epoch)
            
        scheduler_dic.step()
        scheduler_gen.step()

        # Valid Step!
        if (epoch+1) % network_cfg.valid_interval == 0:
            valid_loss = dict()
            GenNet.eval()
            DiscNet.eval()
            for ii, (src_img, tgt_img) in enumerate(valid_dataloader):
                src_img = V(src_img).to(device)
                tgt_img = V(tgt_img).to(device)
                v_out = GenNet(src_img)
                with torch.no_grad():
                    v_out = GenNet(src_img)
                    v_loss = valid_loss_f(v_out, tgt_img)

                    if rank == 0 and (ii+1) % 5 == 0:
                        pic_dir = network_cfg.log_dir+"/sample"
                        os.makedirs(pic_dir, exist_ok=True)
                        org_show = torch.nn.functional.interpolate(src_img, network_cfg.valid_img_size, mode="bilinear")
                        result = torch.cat((org_show, tgt_img, v_out), 2)
                        save_image(result, os.path.join(pic_dir, f"{epoch+1}_{ii}.png"))

                for loss_item, loss_val in v_loss.items():
                    if loss_item not in valid_loss:
                        valid_loss[loss_item] = loss_val.item()
                    else:
                        valid_loss[loss_item] += loss_val.item()  
            loss_info = ""              
            for loss_item, loss_val in valid_loss.items():
                valid_loss[loss_item] /= (ii+1)
                loss_info += "{}={:.4f}\t ".format(loss_item, valid_loss[loss_item])
                if rank == 0:
                    writer.add_scalar('ValidLoss/{}'.format(loss_item),valid_loss[loss_item], (epoch+1)*len(train_dataloader))

            if rank == 0:
                logger.info('Validating Step:\t {}'.format(loss_info))
        
        if (epoch+1) % network_cfg.checkpoint_save_interval == 0:
            torch.save(GenNet.module.state_dict(), network_cfg.gen_checkpoints_dir+"/{}.pth".format(epoch+1))
            torch.save(DiscNet.module.state_dict(), network_cfg.disc_checkpoints_dir+"/{}.pth".format(epoch+1))
    # 删除临时缓存文件
    if rank == 0:
        if os.path.exists(gen_init_weight):
            os.remove(gen_init_weight)
        if os.path.exists(disc_init_weight):
            os.remove(disc_init_weight)
    cleanup()
    writer.close()

if __name__ == '__main__':
	train()
