
import random
import torch
import numpy as np

"""
数据预处理工具
1、所有数据预处理函数都包含两个输入: img 、label
2、img、label的输入维度为3维[C,H,W]，第一个维度是通道数
"""

class TransformCompose(object):

    """Composes several transforms together.
    Args:
        transforms (list of ``Transform`` objects): list of transforms to compose.
    """
    def __init__(self, transforms):
        self.transforms = transforms

    def __call__(self, img, label):
        for t in self.transforms:
            img, label = t(img, label)
        return img, label

    def __repr__(self):
        format_string = self.__class__.__name__ + '('
        for t in self.transforms:
            format_string += '\n'
            format_string += '    {0}'.format(t)
        format_string += '\n)'
        return format_string

class to_tensor(object):
    def __call__(self, img, label):
        img_o = torch.from_numpy(img)
        label_o = torch.from_numpy(label)
        return img_o, label_o

class random_flip(object):
    def __init__(self, axis=1, prob=0.5):
        assert isinstance(axis, int) and axis in [1,2]
        self.axis = axis
        self.prob = prob

    def __call__(self, img, label):
        img_o, label_o = img, label
        if random.random() < self.prob:
            img_o = torch.flip(img, [self.axis])
            label_o = torch.flip(label, [self.axis])
        return img_o, label_o

class random_rotate90(object):
    def __init__(self, k=1, prob=0.5):
        assert isinstance(k, int) and k in [1,2,3]
        self.k = k
        self.prob = prob

    def __call__(self, img, label):
        img_o, label_o = img, label
        if random.random() < self.prob:
            img_o = torch.rot90(img, self.k, [1, 2])
            label_o = torch.rot90(label, self.k, [1, 2])
        return img_o, label_o


class random_crop_and_resize(object):
    def __init__(self, crop_range=[256, 512], osize=[256, 256]):
        self.crop_range = crop_range
        self.osize = osize

    def __call__(self, img, label):
        # crop
        d, w = img.shape[1:]
        crop_size = random.randint(self.crop_range[0], self.crop_range[1])
        crop_x_start = random.randint(0, max(0, d - crop_size))
        crop_y_start = random.randint(0, max(0, w - crop_size))
        img_o = img[:, crop_x_start:crop_x_start+crop_size, crop_y_start:crop_y_start+crop_size]
        label_o = label[:, crop_x_start:crop_x_start+crop_size, crop_y_start:crop_y_start+crop_size]  

        # resize
        if tuple(img_o.shape[1:]) == tuple(label_o.shape[1:]) and tuple(img_o.shape[1:]) == tuple(self.osize):
            return img_o, label_o
        img_o = torch.nn.functional.interpolate(img_o[None], size=self.osize, mode="bicubic") 
        label_o = torch.nn.functional.interpolate(label_o[None], size=self.osize, mode="bicubic") 
        img_o = img_o.squeeze(0)
        label_o = label_o.squeeze(0)
        return img_o, label_o


class random_blur(object):
    def __init__(self, radius_range=[1,5], sigma_range=[0.2, 2], prob=0.5):
        self.radius_range = radius_range
        self.sigma_range = sigma_range
        self.prob = prob
        
    def __call__(self, img, label):
        img_o, label_o = img, label
        if random.random() < self.prob:
            mode = random.choice(['gaussian', 'motion'])
            blur_radius = random.randint(self.radius_range[0], self.radius_range[1])
            if mode == "gaussian":
                blur_sigma = random.uniform(self.sigma_range[0], self.sigma_range[1])
                img_o = self.apply_gaussian_blur(img, blur_radius, blur_sigma)
            else:
                angle = random.uniform(0, 360)
                img_o = self.apply_motion_blur(img, blur_radius, angle)
        return img_o, label_o

    def apply_gaussian_blur(self, img, kernel_radius, sigma):
        """
        Gaussian smooth for a 2D image of type torch tensor.
        """
        kernel_size = kernel_radius * 2 + 1
        img = img.unsqueeze(0)
        # Generate Gaussian kernel
        assert sigma > 0
        X = torch.linspace(-sigma*3, sigma*3, kernel_size)
        Y = torch.linspace(-sigma*3, sigma*3, kernel_size)
        x, y = torch.meshgrid(X, Y)
        gauss_kernel = 1 / (2 * torch.pi * sigma**2) * torch.exp(-(x**2 + y**2) / (2 * sigma**2))
        gauss_kernel = gauss_kernel / gauss_kernel.sum()
        gauss_kernel = torch.FloatTensor(gauss_kernel).unsqueeze(0).unsqueeze(0).to(img.device).type_as(img) 
        weight = torch.nn.Parameter(data=gauss_kernel, requires_grad=False)
        out = torch.nn.functional.conv2d(img, weight, padding=kernel_size // 2).squeeze(0)
        return out
    
    def apply_motion_blur(self, img, kernel_radius, angle):
        img = img.unsqueeze(0)
        # 生成运动核
        kernel_size = kernel_radius * 2 + 1
        kernel = torch.zeros((kernel_size, kernel_size))
        angle_rad = np.radians(angle)
        center = (kernel_size - 1) / 2

        for i in range(kernel_size):
            y = i - center
            x = np.cos(angle_rad) * y
            kernel[i, :] = np.abs(x - np.round(x))

        kernel /= torch.sum(torch.abs(kernel))

        # 将核转换为适用于卷积的形状
        kernel = kernel.unsqueeze(0).unsqueeze(0).to(img.device).type_as(img) 
        weight = torch.nn.Parameter(data=kernel, requires_grad=False)
        out = torch.nn.functional.conv2d(img, weight, padding=kernel_size // 2).squeeze(0)
        return out


class random_add_noise(object):
    def __init__(self, sigma_range=[0.1, 0.3], prob=0.5):
        self.sigma_range = sigma_range
        self.prob = prob

    def __call__(self, img, mask):
        img_o, mask_o = img, mask  
        if random.random() < self.prob:
            sigma = random.uniform(self.sigma_range[0], self.sigma_range[1])
            mode = random.choice(['rayleigh', 'gaussian'])
            if mode == "gaussian":
                noise = torch.randn_like(img) * sigma
            else:
                noise = np.random.rayleigh(scale=sigma, size=img.shape)
                noise = torch.from_numpy(noise).float()
            noisy_image = img + noise
            img_o = torch.clip(noisy_image, 0, 1)
        return img_o, mask_o



class downsample(object):
    def __init__(self, scale_factor):
        self.scale_factor = scale_factor

    def __call__(self, img, label):
        mode = random.choice(['area', 'bilinear', 'bicubic'])
        img_o = torch.nn.functional.interpolate(img[None], scale_factor=self.scale_factor, mode=mode) 
        label_o = label
        img_o = img_o.squeeze(0)
        return img_o, label_o


class normlize(object):
    def __init__(self, win_clip=None):
        self.win_clip = win_clip

    def __call__(self, img, label):  
        if self.win_clip is not None:
            img = torch.clip(img, self.win_clip[0], self.win_clip[1])
            label = torch.clip(label, self.win_clip[0], self.win_clip[1])
        img_o = self._norm(img)
        label_o = self._norm(label)      
        return img_o, label_o
    
    def _norm(self, img):
        ori_shape = img.shape
        img_flatten = img.reshape(ori_shape[0], -1)
        img_min = img_flatten.min(dim=-1,keepdim=True)[0]
        img_max = img_flatten.max(dim=-1,keepdim=True)[0]
        img_norm = (img_flatten - img_min)/(img_max - img_min)
        img_norm = img_norm.reshape(ori_shape)
        return img_norm


class resize(object):
    def __init__(self, size):
        self.size = size

    def __call__(self, img, label):
        if tuple(img.shape[1:]) == tuple(label.shape[1:]) and tuple(img.shape[1:]) == tuple(self.size):
            return img, label
        img_o = torch.nn.functional.interpolate(img[None], size=self.size, mode="bicubic") 
        label_o = torch.nn.functional.interpolate(label[None], size=self.size, mode="bicubic")
        img_o = img_o.squeeze(0)
        label_o = label_o.squeeze(0)
        return img_o, label_o


class random_center_crop(object):
    def __init__(self, crop_size, shift_range, prob=0.5):
        self.crop_size = crop_size
        self.shift_range = shift_range
        self.prob = prob

    def __call__(self, img, label):
        img_o, label_o = img, label
        d, w = img.shape[1:]
        if d <= self.crop_size[0] or w <= self.crop_size[1]:
            return img_o, label_o
        if random.random() < self.prob:
            crop_x_start = min(max(0, (d - self.crop_size[0])//2-random.randint(-self.shift_range[0], self.shift_range[0])), d-self.crop_size[0])
            crop_y_start = min(max(0, (w - self.crop_size[1])//2-random.randint(-self.shift_range[1], self.shift_range[1])), w-self.crop_size[1])
            img_o = img[:, crop_x_start:crop_x_start+self.crop_size[0], crop_y_start:crop_y_start+self.crop_size[1]]
            label_o = label[:, crop_x_start:crop_x_start+self.crop_size[0], crop_y_start:crop_y_start+self.crop_size[1]]         
        return img_o, label_o


class random_crop(object):
    def __init__(self, crop_size):
        self.crop_size = crop_size

    def __call__(self, img, label):
        d, w = img.shape[1:]
        crop_x_start = random.randint(0, max(0, d - self.crop_size[0]))
        crop_y_start = random.randint(0, max(0, w - self.crop_size[1]))
        img_o = img[:, crop_x_start:crop_x_start+self.crop_size[0], crop_y_start:crop_y_start+self.crop_size[1]]
        label_o = label[:, crop_x_start:crop_x_start+self.crop_size[0], crop_y_start:crop_y_start+self.crop_size[1]]            
        return img_o, label_o