import torch
import torch.nn as nn

class ConvBlock(nn.Module):
    def __init__(self,in_channels, out_channels, use_act, **kwargs):
        super().__init__()
        self.cnn = nn.Conv2d(in_channels, out_channels, **kwargs, bias=True)
        self.act = nn.LeakyReLU(0.2, inplace=True) if use_act else nn.Identity()
    
    def forward(self,x):
        return self.act(self.cnn(x))

class DenseResidualBlock(nn.Module):
    def __init__(self, in_channels, channels = 32, n_convs = 5, residual_beta = 0.2):
        super().__init__()
        self.residual_beta = residual_beta
        self.blocks = nn.ModuleList()
        for i in range(n_convs):
            self.blocks.append(
                ConvBlock(in_channels  + channels * i, channels if i<=3 else in_channels,
                kernel_size = 3,stride = 1, padding = 1, use_act=True if i<=3 else False)
            )
    
    def forward(self,x):
        new_inputs = x
        for block in self.blocks:
            out = block(new_inputs)
            new_inputs = torch.cat([new_inputs,out],dim = 1)
        return self.residual_beta * out + x


class RRDB(nn.Module):
    def __init__(self, channels, n_bloacks = 3, residual_beta = 0.2):
        super().__init__()
        self.residual_beta = residual_beta
        self.rrdb = nn.Sequential(*[DenseResidualBlock(channels) for _ in range(n_bloacks)])
    
    def forward(self,x):
        return self.rrdb(x) * self.residual_beta + x


class ESRNet(nn.Module):
    def __init__(self, in_chans, num_chans=64, num_blocks=23, residual_beta = 0.2):
        super().__init__()
        self.residual_beta = residual_beta
        self.initial = nn.Conv2d(in_chans,num_chans,kernel_size=3,stride=1,padding=1,bias=True)     
        self.residuals = nn.Sequential(*[RRDB(num_chans) for _ in range(num_blocks)])
        self.conv = nn.Conv2d(num_chans,num_chans,kernel_size=3, stride=1, padding=1)
    
    def forward(self,x):
        initial = self.initial(x)
        x = self.residuals(initial)
        x = self.residuals(initial)
        out = self.conv(x) + initial
        return out

if __name__ == '__main__':
    model = ESRNet(
        in_chans=1, 
        num_chans=32,
        num_blocks=2,
        residual_beta=0.2
        ).cuda()
    x = torch.randn((1, 1, 320, 320)).cuda()
    x = model(x)
    print(x.shape)
