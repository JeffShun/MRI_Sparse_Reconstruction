
import torch.nn as nn

class ConvBlock(nn.Module):
    def __init__(self,in_channels, out_channels, use_act, **kwargs):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, **kwargs, bias=True)
        self.bn = nn.BatchNorm2d(out_channels)
        self.act = nn.LeakyReLU(0.2, inplace=True) if use_act else nn.Identity()
    
    def forward(self,x):
        return self.act(self.bn(self.conv(x)))


class Discriminator(nn.Module):
    def __init__(
            self, 
            in_channels=1, 
            features=[64, 64, 128, 128, 256, 256, 512, 512],
            apply_sync_batchnorm=True
            ):
        super().__init__()
        blocks = []
        for idx, feature in enumerate(features):
            blocks.append(
                ConvBlock(
                    in_channels,
                    feature,
                    kernel_size=3,
                    stride=1 + idx % 2,
                    padding=1,
                    use_act=True,
                ),
            )
            in_channels = feature

        self.blocks = nn.Sequential(*blocks)
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(512, 1024),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, 1),
        )

        self.initialize_weights()
        if apply_sync_batchnorm:
            self._apply_sync_batchnorm()

    def forward(self, x):
        x = self.blocks(x)
        x = self.classifier(x)
        return x
    
    def initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight.data, mode="fan_out", nonlinearity="leaky_relu")
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight.data, 0, 0.01)
                m.bias.data.zero_()

    def _apply_sync_batchnorm(self):
        print('Apply sync batch norm for Discriminator!')
        self.blocks = nn.SyncBatchNorm.convert_sync_batchnorm(self.blocks)