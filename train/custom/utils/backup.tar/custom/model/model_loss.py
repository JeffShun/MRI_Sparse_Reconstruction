
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models import vgg19
import os

class LossDropoutWrapper(nn.Module):
    def __init__(self, loss_obj, drop_p=0.5, beta=5):
        super(LossDropoutWrapper, self).__init__()
        self.drop_p = drop_p
        self.loss_obj = loss_obj
        self.beta = beta

    def forward(self, X, Y):
        loss = list(self.loss_obj(X, Y).values())[0]
        B, C, H, W = loss.shape
        assert C == 1 
        loss_flat = loss.view(B,-1)
        # softmax
        loss_norm = F.softmax(-loss_flat*self.beta, dim=-1)
        drop_p = self.drop_p * H * W * loss_norm
        random_map = torch.rand_like(drop_p)
        loss_weight = (random_map > drop_p).int()
        # print(loss_weight.sum()/(B*C*H*W))
        dropped_loss = (loss_flat * loss_weight).sum()/(loss_weight.sum())
        return dropped_loss


class SSIMLoss(nn.Module):
    """
    SSIM loss module.
    """

    def __init__(self, win_size: int = 7, k1: float = 0.01, k2: float = 0.03, reduce: bool = True, return_dict=True):
        """
        Args:
            win_size: Window size for SSIM calculation.
            k1: k1 parameter for SSIM calculation.
            k2: k2 parameter for SSIM calculation.
        """
        super(SSIMLoss, self).__init__()
        self.return_dict = return_dict
        self.reduce = reduce
        self.win_size = win_size
        self.k1, self.k2 = k1, k2
        self.register_buffer("w", torch.ones(1, 1, win_size, win_size) / win_size**2)
        NP = win_size**2
        self.cov_norm = NP / (NP - 1)

    def forward(self, X: torch.Tensor, Y: torch.Tensor):
        assert isinstance(self.w, torch.Tensor)
        B, C, W, D = Y.shape
        max_values, _ = torch.max(Y.view(B, C, -1), -1)
        max_values = max_values[:, :, None, None]
        C1 = (self.k1 * max_values) ** 2
        C2 = (self.k2 * max_values) ** 2
        self.w = self.w.to(X.device)
        ux = F.conv2d(X, self.w)  # typing: ignore
        uy = F.conv2d(Y, self.w)  #
        uxx = F.conv2d(X * X, self.w)
        uyy = F.conv2d(Y * Y, self.w)
        uxy = F.conv2d(X * Y, self.w)
        vx = self.cov_norm * (uxx - ux * ux)
        vy = self.cov_norm * (uyy - uy * uy)
        vxy = self.cov_norm * (uxy - ux * uy)
        A1, A2, B1, B2 = (
            2 * ux * uy + C1,
            2 * vxy + C2,
            ux**2 + uy**2 + C1,
            vx + vy + C2,
        )
        D = B1 * B2
        S = (A1 * A2) / D
        loss = 1 - S
        if self.reduce:
            loss = loss.mean()
        if self.return_dict:
            return {"SSIMLoss":loss}
        return loss
        

class PerceptualLoss(nn.Module):
    def __init__(self, vgg_weight_path):
        super(PerceptualLoss, self).__init__()
        if os.path.exists(vgg_weight_path):
            self.vgg = vgg19()
            self.vgg.load_state_dict(torch.load(vgg_weight_path))
        else:
            self.vgg = vgg19(pretrained=True)
        self.fea_extractor = self.vgg.features[:35].eval()
        for param in self.fea_extractor.parameters():
            param.requires_grad = False
        self.loss = nn.MSELoss()
    
    def forward(self, fake, target):
        
        fea_extractor = self.fea_extractor.to(fake.device)
        fake = torch.cat([fake, fake, fake], dim=1)
        target = torch.cat([target, target, target], dim=1)

        vgg_input_features = fea_extractor(fake)
        vgg_target_features = fea_extractor(target)

        return self.loss(vgg_input_features, vgg_target_features)


class GradientPenalty(nn.Module):
    def __init__(self):
        super(GradientPenalty, self).__init__()

    def forward(self, fake_img, real_img, discriminator):
        BATCH_SIZE, C, H, W = real_img.shape
        alpha = torch.rand((BATCH_SIZE, 1, 1, 1)).repeat(1, C, H, W).to(real_img.device)
        interpolated_images = real_img * alpha + fake_img.detach() * (1 - alpha)
        interpolated_images.requires_grad_(True)

        # Calculate critic scores
        mixed_scores = discriminator(interpolated_images)

        # Take the gradient of the scores with respect to the images
        gradient = torch.autograd.grad(
            inputs=interpolated_images,
            outputs=mixed_scores,
            grad_outputs=torch.ones_like(mixed_scores),
            create_graph=True,
            retain_graph=True,
        )[0]
        gradient = gradient.view(gradient.shape[0], -1)
        gradient_norm = gradient.norm(2, dim=1)
        gradient_penalty = torch.mean((gradient_norm - 1) ** 2)
        return gradient_penalty


class GeneratorLoss(nn.Module):
    def __init__(
            self, 
            vgg_weight_path, 
            ContentLoss_Weight=1e-2,
            VGGLoss_Weight = 1.0,
            AdversarialLoss_Weight = 5e-3
            ):
        super(GeneratorLoss, self).__init__()
        # self.ContentLoss = nn.L1Loss()
        self.ContentLoss = SSIMLoss(return_dict=False)
        self.VGGLoss = PerceptualLoss(vgg_weight_path)
        self.AdversarialLoss = nn.BCEWithLogitsLoss()

        self.ContentLoss_Weight = ContentLoss_Weight
        self.VGGLoss_Weight = VGGLoss_Weight
        self.AdversarialLoss_Weight = AdversarialLoss_Weight


    def forward(self, fake_img, real_img, discriminator):

        ContentLoss = self.ContentLoss_Weight * self.ContentLoss(fake_img, real_img)
        VGGLoss = self.VGGLoss_Weight * self.VGGLoss(fake_img, real_img)
        
        fake_score = discriminator(fake_img)
        real_score = discriminator(real_img)

        fake_label = torch.full([fake_img.shape[0], 1], 0.0, dtype=torch.float, device=fake_img.device)
        real_label = torch.full([fake_img.shape[0], 1], 1.0, dtype=torch.float, device=real_img.device)
        
        AdversarialLoss = 0.5 * self.AdversarialLoss_Weight * (
            self.AdversarialLoss(real_score - torch.mean(fake_score), fake_label) + \
            self.AdversarialLoss(fake_score - torch.mean(real_score), real_label)
        )
        all_loss = {
            "ContentLoss": ContentLoss,
            "VGGLoss" : VGGLoss,
            "AdversarialLoss": AdversarialLoss
        }
        return all_loss
    

class DiscriminatorLoss(nn.Module):
    def __init__(self, AdversarialLoss_Weight = 1.0):
        super(DiscriminatorLoss, self).__init__()
        self.AdversarialLoss = nn.BCEWithLogitsLoss()
        self.AdversarialLoss_Weight = AdversarialLoss_Weight

    def forward(self, fake_img, real_img, discriminator):
        fake_score = discriminator(fake_img.detach())
        real_score = discriminator(real_img)

        fake_label = torch.full([fake_img.shape[0], 1], 0.0, dtype=torch.float, device=fake_img.device)
        real_label = torch.full([fake_img.shape[0], 1], 1.0, dtype=torch.float, device=real_img.device)

        AdversarialLoss = self.AdversarialLoss_Weight * (
            self.AdversarialLoss(real_score - torch.mean(fake_score), real_label) + \
            self.AdversarialLoss(fake_score - torch.mean(real_score), fake_label)
        )
        

        all_loss = {
            "AdversarialLoss": AdversarialLoss,
        }

        return all_loss