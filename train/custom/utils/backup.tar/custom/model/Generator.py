import torch
import torch.nn as nn

class Generator(nn.Module):
    def __init__(
        self,
        backbone,
        inchans,
        outchans,
        scale_factor = 2,
        interp_mode = "nearest",
        global_residual=False,
        apply_sync_batchnorm=True
        ):
        super(Generator, self).__init__()
        self.backbone = backbone
        self.global_residual = global_residual
        self.scale_factor = scale_factor
        if self.scale_factor > 1:
            if interp_mode in ["nearest", "bilinear", "bicubic"]:
                self.upsample = nn.Sequential(
                    nn.Upsample(scale_factor=scale_factor,mode="nearest"),
                    nn.Conv2d(inchans,inchans,3,1,1,bias=True),
                    nn.LeakyReLU(0.2, inplace=True)
                    )
            else:
                self.upsample = nn.Sequential(
                    nn.Conv2d(inchans, inchans * (scale_factor**2),3,1,1,bias=True),
                    nn.PixelShuffle(scale_factor),
                    nn.LeakyReLU(0.2, inplace=True)
                    )                 
        
        self.final = nn.Sequential(
            nn.Conv2d(inchans, inchans, 3, 1, 1, bias=True),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(inchans, outchans, 3, 1, 1, bias=True)
            )

        self.initialize_weights()
        if apply_sync_batchnorm:
            self._apply_sync_batchnorm()

    def forward(self, img):
        x = self.backbone(img)
        if self.scale_factor > 1:
            x = self.upsample(x)
        x = self.final(x)
        if self.global_residual and self.scale_factor==1:
            return torch.sub(img, x)
        return x

    def initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                torch.nn.init.kaiming_normal_(m.weight.data, mode="fan_out", nonlinearity="leaky_relu")
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                torch.nn.init.normal_(m.weight.data, 0, 0.01)
                m.bias.data.zero_()

    def _apply_sync_batchnorm(self):
        print('Apply sync batch norm for Generator!')
        self.backbone = nn.SyncBatchNorm.convert_sync_batchnorm(self.backbone)