import sys, os
work_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(work_dir)
import torch
from custom.dataset.dataset import MyDataset
from custom.utils.data_transforms import *
from custom.model.backbones.ResUnet import ResUnet
from custom.model.backbones.MWResUNet import MWResUnet
from custom.model.backbones.DnCNN import DnCNN
from custom.model.backbones.SwinIR import SwinIR
from custom.model.backbones.Restormer import Restormer
from custom.model.backbones.MWCNN import MWCNN
from custom.model.backbones.ESRNet import ESRNet
from custom.model.Discriminator import Discriminator
from custom.model.Generator import Generator
from custom.model.model_loss import GeneratorLoss, DiscriminatorLoss, SSIMLoss

class network_cfg:

    device = torch.device('cuda')
    dist_backend = 'nccl'
    dist_url = 'env://'

    # img
    train_img_size = (256, 256)
    valid_img_size = (256, 256)

    # network
    gen_network = Generator(
        # backbone = ESRNet(
        #     in_chans = 1, 
        #     num_chans = 64, 
        #     num_blocks = 6, 
        #     residual_beta = 0.2
        #     ),
        backbone = ResUnet(
            in_chans=1, 
            num_chans=64,
            n_res_blocks=2
            ),
        inchans = 64,
        outchans = 1,
        scale_factor = 1,
        interp_mode = "nearest",
        global_residual = True,
        apply_sync_batchnorm=False
        )

    disc_network = Discriminator(
        in_channels = 1,
        features=[64, 64, 128, 128, 256, 256, 512, 512],
        apply_sync_batchnorm=False
    )

    # loss function
    train_gen_loss_f = GeneratorLoss(
        vgg_weight_path = work_dir + '/checkpoints/vgg_pretrain/vgg19.pth', 
        ContentLoss_Weight=1.0,
        VGGLoss_Weight = 0.01,
        AdversarialLoss_Weight = 0.005
    )
    
    train_disc_loss_f = DiscriminatorLoss(AdversarialLoss_Weight=0.005)
    
    valid_loss_f = SSIMLoss(win_size = 7, k1 = 0.01, k2 = 0.03, reduce=True)

    # dataset
    train_dataset = MyDataset(
        dst_list_file = work_dir + "/train_data/processed_data/Para4/train.txt",
        transforms = TransformCompose([
            to_tensor(),
            normlize(win_clip=None),
            random_flip(axis=1, prob=0.5),
            random_flip(axis=2, prob=0.5),
            random_rotate90(k=1, prob=0.5),
            random_crop_and_resize(crop_range=[160, 512], osize=train_img_size),
            random_blur(radius_range=[3, 9], sigma_range=[0.01, 1], prob=0.3),
            random_add_noise(sigma_range=[0.05, 0.1], prob=0.3),
            # downsample(scale_factor=0.5),
            ])
        )
    
    valid_dataset = MyDataset(
        dst_list_file = work_dir + "/train_data/processed_data/Para4/valid.txt",
        transforms = TransformCompose([
            to_tensor(),
            normlize(win_clip=None),
            random_crop_and_resize(crop_range=[160, 512], osize=valid_img_size),
            random_blur(radius_range=[3, 9], sigma_range=[0.01, 1], prob=0.3),
            random_add_noise(sigma_range=[0.05, 0.1], prob=0.3),
            # downsample(scale_factor=0.5),
            ])
        )
    
    # train dataloader
    batchsize = 4
    shuffle = True
    num_workers = 4
    drop_last = False

    # optimizer
    lr = 1e-4
    weight_decay = 5e-4

    # scheduler
    milestones = [40,80,120]
    gamma = 0.5
    warmup_factor = 0.1
    warmup_iters = 1
    warmup_method = "linear"
    last_epoch = -1

    # debug
    total_epochs = 150
    valid_interval = 1
    checkpoint_save_interval = 1
    log_dir = work_dir + "/Logs/Para4/ResUnet-Denose-AUG"
    gen_checkpoints_dir = work_dir + '/checkpoints/Para4/ResUnet-Denose-AUG/Generator'
    disc_checkpoints_dir = work_dir + '/checkpoints/Para4/ResUnet-Denose-AUG/Discriminator'
    
    gen_load_from = work_dir + '/checkpoints/Para4/ResUnet-Denose/Generator/50.pth'
    disc_load_from = work_dir + '/checkpoints/Para4/ResUnet-Denose/Discriminator/50.pth'

